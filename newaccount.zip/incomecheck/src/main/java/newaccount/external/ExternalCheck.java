package newaccount.external;

import java.util.Date;
import lombok.Data;

@Data
public class ExternalCheck {

    private Long id;
    private String regNo;
    private Long incomeExtAmt;
    // keep

}
